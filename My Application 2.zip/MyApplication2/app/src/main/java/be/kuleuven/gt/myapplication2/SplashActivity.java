package be.kuleuven.gt.myapplication2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    private static final int SPLASH_DELAY = 2000;
    private static final String PREFS_NAME = "MyAppPrefs";
    private static final String KEY_IS_REGISTERED = "isRegistered";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean isRegistered = prefs.getBoolean(KEY_IS_REGISTERED, false);

            Intent intent;
            if (isRegistered) {
                // Go to MainActivity if user already registered
                intent = new Intent(SplashActivity.this, MainActivity.class);
            } else {
                // Otherwise go to RegisterActivity
                intent = new Intent(SplashActivity.this, RegisterActivity.class);
            }

            startActivity(intent);
            finish();
        }, SPLASH_DELAY);
    }
}
