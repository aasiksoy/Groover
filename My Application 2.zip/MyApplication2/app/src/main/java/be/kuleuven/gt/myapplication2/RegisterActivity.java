package be.kuleuven.gt.myapplication2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText inputUsername, inputEmail, inputPassword;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        ConstraintLayout layout = findViewById(R.id.registerLayout);

        ViewCompat.setOnApplyWindowInsetsListener(layout, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        inputUsername = findViewById(R.id.inputUsername);
        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(v -> {
            String username = inputUsername.getText().toString().trim();
            String email = inputEmail.getText().toString().trim();
            String password = inputPassword.getText().toString().trim();

            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show();
            } else {
                checkUserAndRegister(username, email, password);
            }
        });
    }

    private void checkUserAndRegister(String username, String email, String password) {
        String checkUrl = "https://studev.groept.be/api/a24pt103/check_user_exists";

        StringRequest checkRequest = new StringRequest(Request.Method.POST, checkUrl,
                response -> {
                    if (response.contains("1")) {
                        Toast.makeText(this, "Username or email already exists!", Toast.LENGTH_LONG).show();
                    } else {
                        registerUser(username, email, password);
                    }
                },
                error -> Toast.makeText(this, "Check failed: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("a", username);
                params.put("b", email);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(checkRequest);
    }

    private void registerUser(String username, String email, String password) {
        String URL = "https://studev.groept.be/api/a24pt103/register_user";

        StringRequest request = new StringRequest(Request.Method.POST, URL,
                response -> {
                    Toast.makeText(this, "Registered successfully!", Toast.LENGTH_LONG).show();

                    SharedPreferences preferences = getSharedPreferences("grooverPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("isRegistered", true);
                    editor.putString("username", username);
                    editor.apply();

                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                },
                error -> Toast.makeText(this, "Registration failed: " + error.getMessage(), Toast.LENGTH_LONG).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> postData = new HashMap<>();
                postData.put("a", username);
                postData.put("b", email);
                postData.put("c", password);
                return postData;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}
