package be.kuleuven.gt.myapplication2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private static final String CLIENT_ID = "1a5a73d460754f54b4d63431c494ee0f";
    private static final String REDIRECT_URI = "grooverapp://callback";
    private static final String AUTH_URL = "https://accounts.spotify.com/authorize";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Check if already registered
        SharedPreferences prefs = getSharedPreferences("grooverPrefs", MODE_PRIVATE);
        boolean isRegistered = prefs.getBoolean("isRegistered", false);

        if (isRegistered) {
            goToMain();
            return;
        }

        findViewById(R.id.btnSpotifyLogin).setOnClickListener(v -> launchSpotifyLogin());
    }

    private void launchSpotifyLogin() {
        Uri uri = Uri.parse(AUTH_URL)
                .buildUpon()
                .appendQueryParameter("client_id", CLIENT_ID)
                .appendQueryParameter("response_type", "token")
                .appendQueryParameter("redirect_uri", REDIRECT_URI)
                .appendQueryParameter("scope", "user-read-private user-read-email user-top-read")
                .build();

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleSpotifyRedirect(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handleSpotifyRedirect(getIntent());
    }

    private void handleSpotifyRedirect(Intent intent) {
        Uri uri = intent.getData();
        if (uri != null && uri.toString().startsWith(REDIRECT_URI)) {
            String fragment = uri.getFragment();
            if (fragment != null) {
                for (String param : fragment.split("&")) {
                    if (param.startsWith("access_token=")) {
                        String token = param.substring("access_token=".length());

                        getSharedPreferences("grooverPrefs", MODE_PRIVATE)
                                .edit()
                                .putString("SPOTIFY_TOKEN", token)
                                .apply();

                        Toast.makeText(this, "Logged in with Spotify!", Toast.LENGTH_SHORT).show();
                        Log.d("SPOTIFY_TOKEN", token);

                        goToRegister(); // Only after Spotify login
                        return;
                    }
                }
            }
        }
    }

    private void goToRegister() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
        finish();
    }

    private void goToMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
